const express = require("express");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));
const questions = [
 {id:1,question:"ইসলামের প্রথম স্তম্ভ কোনটি?",options:["সালাত","সাওম","শাহাদাহ","যাকাত"]},
 {id:2,question:"এক দিনে ফরজ নামাজ কত ওয়াক্ত?",options:["৩ ওয়াক্ত","৪ ওয়াক্ত","৫ ওয়াক্ত","৬ ওয়াক্ত"]},
 {id:3,question:"পবিত্র কুরআন কোন মাসে নাজিল শুরু হয়?",options:["শাবান","রমজান","মুহররম","শাওয়াল"]}
];
const correctAnswers={1:2,2:2,3:1};
let leaderboard=[];
app.get("/api/quiz",(req,res)=>res.json({success:true,questions}));
app.post("/api/quiz/submit",(req,res)=>{const {userId,name,answers}=req.body;let score=0;questions.forEach(q=>{if(answers&&answers[q.id]===correctAnswers[q.id])score++;});leaderboard.push({userId:userId||"guest",name:name||"Guest",score,total:questions.length});leaderboard.sort((a,b)=>b.score-a.score);res.json({success:true,score,total:questions.length});});
app.get("/api/leaderboard",(req,res)=>res.json({success:true,leaderboard:leaderboard.slice(0,20)}));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`Mijan Islamik Quiz running on port ${PORT}`));
